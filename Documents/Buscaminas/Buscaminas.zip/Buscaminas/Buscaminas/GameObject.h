#pragma once
class GameObject
{
public:
	float x;

	float y;
};

